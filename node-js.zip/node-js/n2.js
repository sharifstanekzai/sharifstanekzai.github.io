var myDate=function(){
    return new Date();
};
exports.myDate=myDate;